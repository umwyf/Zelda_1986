using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HasElectricity : MonoBehaviour
{
    public enum Electricity
    {
        Negative,
        Neutral,
        Positive
    };

    public Electricity electricity = Electricity.Negative;

    public bool autoMode = false;

    [Header("Sprites for each electricity state")]
    public Sprite negativeSprite = null;
    public Sprite neutralSprite = null;
    public Sprite positiveSprite = null;

    private SpriteRenderer spriteRenderer;

    // Start is called before the first frame update
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        UpdateSpriteBasedOnElectricity();

        // Start the auto change electricity coroutine
        if(autoMode == true) StartCoroutine(AutoChangeElectricity());
    }

    // Update is called once per frame
    void Update()
    {
        // Sample code to change states for testing.
        if (Input.GetKeyDown(KeyCode.Space) && gameObject.tag == "Player")
        {
            ChangeElectricity();
            UpdateSpriteBasedOnElectricity();
        }
    }

    void UpdateSpriteBasedOnElectricity()
    {
        switch (electricity)
        {
            case Electricity.Negative:
                if (negativeSprite != null) spriteRenderer.sprite = negativeSprite;
                break;

            case Electricity.Neutral:
                if (neutralSprite != null) spriteRenderer.sprite = neutralSprite;
                break;

            case Electricity.Positive:
                if (positiveSprite != null) spriteRenderer.sprite = positiveSprite;
                break;
        }
    }

    void ChangeElectricity()
    {
        if (electricity == Electricity.Negative)
        {
            electricity = Electricity.Positive;
        }
        else if (electricity == Electricity.Positive)
        {
            electricity = Electricity.Negative;
        }
    }

    IEnumerator AutoChangeElectricity()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);  // wait for 1 second
            ChangeElectricity();
            UpdateSpriteBasedOnElectricity();
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LevelController : MonoBehaviour
{
    public AudioClip level_pass_sound = null;
    public GameObject keys = null;  // Drag the "keys" GameObject here from the Inspector
    public int keysCount = 1;
    public bool isNormalLevel = true;

    private bool levelTransitionInProgress = false;
    private int firstSceneIndex = 0;


    void Start()
    {
        keys = GameObject.Find("Keys");
        // Record the number of children in the "keys" GameObject
        keysCount = keys.transform.childCount;

        // Check the condition
        
    }

    private void Update()
    {
        if (keysCount <= 0 && levelTransitionInProgress == false && isNormalLevel)
        {
            levelTransitionInProgress = true;
            LoadNextLevel();
        }

        if (Input.GetKeyDown(KeyCode.R)) {
            LoadCurrentLevel();
        }

        if (Input.GetKeyDown(KeyCode.M))
        {
            LoadFirstLevel();
        }
    }

    private void PlaySound()
    {
        if (level_pass_sound != null) AudioSource.PlayClipAtPoint(level_pass_sound, Camera.main.transform.position);
    }

    private void LoadCurrentLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private void LoadFirstLevel()
    {

        // Check if the first scene exists
        if (firstSceneIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(firstSceneIndex);
        }
        else
        {
            Debug.LogWarning("First scene does not exist! Please add more scenes to Build Settings.");
        }
    }

    private void LoadNextLevel()
    {
        StartCoroutine(LoadLevelAfterSound());
    }



    private IEnumerator LoadLevelAfterSound()
    {
        PlaySound();

        // Wait for the duration of the sound clip before loading the next scene
        yield return new WaitForSeconds(level_pass_sound.length - 0.5f);

        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;
        if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextSceneIndex);
        }
        else
        {
            Debug.LogWarning("Next scene does not exist! Please add more scenes to Build Settings.");
        }
    }

}



using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyBehavior : MonoBehaviour
{
    // Reference to the sound clip
    public AudioClip keySound;
    public LevelController levelController;
    // Reference to the audio source
    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        levelController = GameObject.Find("LevelController").GetComponent<LevelController>();
        // Get the AudioSource component from this object (or you can attach one if not present)
        audioSource = GetComponent<AudioSource>();

        // If there's no audio source component attached to the object, add one
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        GameObject colliderObject = other.gameObject;
        if (colliderObject.tag == "Player")
        {
            GetKey();
            Destroy(gameObject);
        }
    }

    private void GetKey()
    {
        Debug.Log("KeyBehavior: You got it!");

        // Play the key sound
        if (keySound != null && audioSource != null)
        {
            AudioSource.PlayClipAtPoint(keySound, Camera.main.transform.position);
        }
        levelController.keysCount -= 1;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RestartController : MonoBehaviour
{
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnButtonClick()
    {
        // Get the name of the clicked button (which is set to the scene index)
        string buttonName = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name;

        Debug.Log("Button " + buttonName + " was clicked!");

        // Convert button name to scene index and load the corresponding scene
        int sceneIndex;
        if (int.TryParse(buttonName, out sceneIndex))
        {
            // Check if the scene exists
            if (sceneIndex < SceneManager.sceneCountInBuildSettings)
            {
                SceneManager.LoadScene(sceneIndex);
            }
            else
            {
                Debug.LogWarning("Scene with index " + sceneIndex + " does not exist! Please add it to Build Settings.");
            }
        }
        else
        {
            Debug.LogWarning("Button name is not a valid scene index: " + buttonName);
        }
    }

}

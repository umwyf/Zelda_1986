using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // Add this line

public class BombBehavior : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        GameObject colliderObject = other.gameObject;
        if (colliderObject.tag == "Player")
        {
            Explode();
            Destroy(gameObject);
        }
    }

    private void Explode()
    {
        Debug.Log("BombBehavior: You died!");

        // Reload the current scene
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

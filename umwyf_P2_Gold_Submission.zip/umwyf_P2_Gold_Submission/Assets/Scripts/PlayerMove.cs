using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float moveSpeed = 5f; // Movement speed
    public float rotationSpeed = 100.0f; // Adjust as needed for faster or slower rotation

    private Rigidbody rb;
    private Vector2 moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Get horizontal input (from arrow keys or WASD by default)
        float moveX = Input.GetAxis("Horizontal");

        // Normalize the moveInput vector to ensure diagonal movement isn't faster
        moveInput = new Vector2(moveX, 0).normalized * moveSpeed;

        // Rotate the sphere based on movement
        if (moveX != 0) // Only apply rotation if there's horizontal movement
        {
            Vector3 rotationDirection = Vector3.Cross(new Vector3(moveX, 0, 0).normalized, Vector3.up);
            rb.AddTorque(rotationDirection * rotationSpeed * moveX);
        }
    }

    void FixedUpdate()
    {
        // Set velocity directly for movement
        Vector2 newVelocity = new Vector2(moveInput.x, rb.velocity.y); // Maintain the current y velocity
        rb.velocity = newVelocity;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplyForce : MonoBehaviour
{
    [Header("Force Settings")]
    public float forceAmount = 0.5f;
    public float detectionDistance = 0.5f; // How far the block can detect the player

    private HasElectricity hasElectricity;
    private Vector2[] directions = { Vector2.up, Vector2.down };
    private Light blockLight = null;  // For 3D

    


    void Start()
    {
        hasElectricity = GetComponent<HasElectricity>();
        blockLight = GetComponent<Light>();
    }

    void FixedUpdate()
    {
        foreach (var direction in directions)
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position, direction, out hit, detectionDistance))
            {
                if (hit.collider.gameObject.CompareTag("Player"))
                {
                    HasElectricity playerElectricity = hit.collider.gameObject.GetComponent<HasElectricity>();
                    ApplyElectricForce(playerElectricity, direction);
                }
            }
        }
    }

    void ApplyElectricForce(HasElectricity playerElectricity, Vector2 direction)
    {
        if (hasElectricity.electricity == HasElectricity.Electricity.Neutral)
        {
            // Do nothing if block is neutral
            return;
        }

        // Apply force based on electricity polarity
        if (playerElectricity.electricity == HasElectricity.Electricity.Negative && hasElectricity.electricity == HasElectricity.Electricity.Positive ||
           playerElectricity.electricity == HasElectricity.Electricity.Positive && hasElectricity.electricity == HasElectricity.Electricity.Negative)
        {
            // Opposites attract
            playerElectricity.gameObject.GetComponent<Rigidbody>().AddForce(-direction * forceAmount, ForceMode.Impulse);
            TurnOnLight();
        }
        else
        {
            // Same polarity repels
            playerElectricity.gameObject.GetComponent<Rigidbody>().AddForce(direction * forceAmount, ForceMode.Impulse);
            TurnOnLight();
        }
        TurnOffLight();
    }
    public void TurnOnLight()
    {
        if(blockLight != null) blockLight.intensity = 5;  // Adjust as needed
    }

    public void TurnOffLight()
    {
        if (blockLight != null) blockLight.intensity = 0;
    }
}


